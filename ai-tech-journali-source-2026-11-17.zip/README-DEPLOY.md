# AI Tech Journal — Deploy Bundle

This folder contains the repaired version of https://ahadh7865-cmyk.github.io/ai-tech-journali

Everything below is written for manual upload through the GitHub website.
No scripts push to GitHub, and no Git installation is required.

**Upload this:** `dist\ai-tech-journali-deploy-2026-11-17.zip`
(unzipped copy: `deploy\`). Both have the same 65 files.

---

## 1. Before you deploy: replace the placeholder address (required)

The bundle is built with `editorial@example.com` as a stand-in, because no
real contact address was supplied. `example.com` is a reserved documentation
domain, so anything sent there is lost. Replace it before uploading.

**Quick path** — rebuild the folder and ZIP with your real address:

```powershell
python tools\package_deploy.py you@yourdomain.com
```

That refreshes:

- `deploy\` — the upload-ready folder
- `dist\ai-tech-journali-deploy-<date>.zip` — the same contents, zipped
- prints `No placeholders left` when it is safe to upload

This is the only required step. The script copies `site\`, swaps the address
in 55 `mailto:` links across 32 files (every page plus
`assets\js\main.js`), and rebuilds both outputs. It is safe to re-run with a
different address; `site\` itself keeps the neutral token `__CONTACT_EMAIL__`.

If you prefer to patch by hand instead, replace `editorial@example.com` in
`deploy\` — but the rebuild command above is less error-prone. The address
appears in `mailto:` links and in `var CONTACT_EMAIL` in
`assets\js\main.js`, which the contact form uses to draft a message.

**Note:** a `mailto:` link opens the visitor's own email app. GitHub Pages
cannot receive form submissions, so there is no server-side inbox. The
contact and newsletter forms are honest about this in the page copy.

---

## 2. What is in the bundle

Upload the **contents** of this folder, so that `index.html` sits at the
repository root.

```
index.html                  home page
404.html                    custom not-found page (GitHub Pages serves it automatically)
about.html  contact.html    editorial pages
privacy.html terms.html     policy pages
disclaimer.html
search.html                 dedicated search page
robots.txt  sitemap.xml     crawler files, absolute URLs to the Pages domain
favicon.svg                 tab icon
apple-touch-icon.png        iOS home-screen icon

articles\     14 article pages
categories\   8 desk pages + categories\index.html hub
assets\css\   style.css
assets\js\    main.js, articles-data.js
assets\images\ 25 JPEGs + logo.svg + fallback-image.svg
```

Do **not** upload `_dev\` or `tools\`. They are source/repair utilities,
not part of the site.

---

## 3. Deploy through the GitHub website

The repository currently has every file flattened in the root, including
`style.css`, `main.js`, the images, and old copies of the article pages.
Those old files must be removed, otherwise GitHub keeps serving duplicate
pages at the old addresses.

1. Open https://github.com/ahadh7865-cmyk/ai-tech-journali
2. Delete the old flat files. The quickest safe way:
   - Select all files in the root listing and delete them
     (the repo history is preserved; this is just the current tree).
   - Keep the `.git` folder untouched — you are working in the web UI, so
     nothing local is affected.
3. Click **Add file → Upload files**.
4. Drag the **contents** of this deploy folder into the browser
   (all root files plus the `articles`, `categories`, and `assets` folders).
5. Commit message: `Rebuild site structure and fix broken links`
6. Wait 1–3 minutes for **Settings → Pages** to redeploy.

If you prefer not to delete everything at once, upload first, then delete
only these leftovers: every `.html` at the root except `index.html`,
`about.html`, `contact.html`, `privacy.html`, `terms.html`,
`disclaimer.html`, `search.html`, `404.html`; plus `style.css`, `main.js`,
`articles-data.js`, all `.jpg` files at the root, all `.ps1` files,
`README.md`, and `deploy.yml`.

---

## 4. Verify after deploy

Open each of these and confirm the page looks right and the menu, images,
and footer links work:

- https://ahadh7865-cmyk.github.io/ai-tech-journali/
- https://ahadh7865-cmyk.github.io/ai-tech-journali/articles/agentic-ai-autonomous-workflows-2025.html
- https://ahadh7865-cmyk.github.io/ai-tech-journali/categories/
- https://ahadh7865-cmyk.github.io/ai-tech-journali/search.html
- https://ahadh7865-cmyk.github.io/ai-tech-journali/this-page-does-not-exist
  (should show the custom 404 page)
- https://ahadh7865-cmyk.github.io/ai-tech-journali/sitemap.xml

Search-engine note: after deploying, submit the sitemap in
Google Search Console and Bing Webmaster Tools.

---

## 5. If you move to a custom domain

Every canonical, Open Graph, JSON-LD, share link, sitemap entry and robots
entry uses this base:

```
https://ahadh7865-cmyk.github.io/ai-tech-journali
```

To switch domains, replace that string in all `.html`, `.xml` and `.txt`
files, and add a file named `CNAME` at the repository root containing only
your domain (for example `aitechjournal.com`). Nothing else needs to change.

---

## 6. What was repaired

**Structure (the main cause of the outage)**
- 29 HTML pages, CSS, JS, and images were all flattened in the repo root,
  while every page linked to `assets/`, `articles/`, and `categories/`.
  Roughly 1,700 of 1,915 internal references were broken.
- Files were moved into the intended tree and every page was rewritten to
  match. Current check: **31 pages, 2,092 internal references, 0 broken**.

**Broken behaviour**
- `search.html` threw `SyntaxError: Unexpected identifier 'all'` and never
  rendered results. Rewritten; supports `search.html?q=term`.
- `main.js` was rebuilt: script-URL-derived base path, guarded image
  fallback (the old `onerror` loop could recurse), working mobile drawer
  with ARIA state and scroll lock, search modal focus trap, copy-link,
  toast, and a contact form that opens a pre-filled `mailto:` draft.
- Removed 23 empty ad-slot blocks and dead image references.

**Accuracy and trust**
- Removed unverifiable claims: fabricated ISSN `2831-904X`, "Published
  Daily", "Updated Hourly", "Live Intel", "85,000+ subscribers", fake
  `@aitechjournal.com` addresses, a Silicon Valley office, and 24/7
  monitoring claims.
- Privacy, Terms, and Disclaimer pages were rewritten to describe what the
  site actually does (static hosting, no cookies, no analytics, no ads,
  no server-side form handling).
- About page: removed invented staff biographies and unsupported
  fact-checking claims; desks are now described by coverage area.

**SEO and sharing**
- Absolute canonical, Open Graph and Twitter URLs; missing OG/Twitter tags
  added; JSON-LD validated on all 27 blocks.
- Titles trimmed to 60 characters or fewer and descriptions to 160 or
  fewer on all 29 original pages; added `404.html` and `categories/index.html`.
- Sitemap rebuilt with absolute URLs and real `lastmod` dates; robots.txt
  excludes `search.html` and `404.html`; favicon and theme-color added.
- Share links now include the canonical article URL.

**Images and layout**
- All `<img>` tags have correct `width`/`height`, `decoding="async"`, and
  lazy loading below the fold (no layout shift).
- Recompressed from originals: **3.90 MB → 2.60 MB** (25 JPEGs, max
  1200 px wide). Dropped 3 duplicate or unused images.
- Hamburger nav now activates at ≤1024 px (it used to break the header
  between 769 and 1024 px). Larger tap targets, visible focus outlines,
  and a compact header under 560 px.
- WCAG contrast fixed for muted text and category badges.
  Lighthouse on the home page, an article page, a category page, the
  contact page and search: **Accessibility 100, Best Practices 100, SEO 100**.

---

## 7. Content work still recommended (not changed here)

These are editorial decisions, so they were left for you:

1. **Article dates are stale.** Every article is dated Oct–Nov 2025, over a
   year before today. Consider adding a dated "Update" note or refreshing
   the archive.
2. **Sourcing.** Several articles state benchmark numbers, funding figures,
   and specific company events without citations. Add primary-source links
   (papers, filings, official announcements) or soften the claims. This
   matters more than layout for credibility.
3. **Author identities.** The four author bylines are presented as staff
   journalists. If they are pen names or AI-assisted personas, say so on
   the About page — the current AI-disclosure paragraph leaves room for
   that, but it should be explicit.
4. **Images are illustrative**, not documentary. The disclaimer says so;
   keep it that way when adding new images.
