import io, re

p = 'site/search.html'
t = open(p, encoding='utf-8-sig', newline='').read()

start_marker = "  <script>\r\n    document.addEventListener('DOMContentLoaded'"
if start_marker not in t:
    start_marker = "  <script>\n    document.addEventListener('DOMContentLoaded'"
start = t.index(start_marker)
end_marker = "  </script>\r\n</body>"
if end_marker not in t:
    end_marker = "  </script>\n</body>"
end = t.index(end_marker, start) + len("  </script>")

new_script = """  <script>
    document.addEventListener('DOMContentLoaded', function () {
      var input = document.getElementById('dedicated-search-input');
      var form = document.getElementById('dedicated-search-form');
      var resultsContainer = document.getElementById('dedicated-results');
      var statsContainer = document.getElementById('search-stats');
      var BASE = './';

      function escapeHtml(value) {
        return String(value || '')
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#039;');
      }

      function matchesQuery(article, q) {
        return (
          article.title.toLowerCase().indexOf(q) !== -1 ||
          article.excerpt.toLowerCase().indexOf(q) !== -1 ||
          article.category.toLowerCase().indexOf(q) !== -1 ||
          article.author.name.toLowerCase().indexOf(q) !== -1 ||
          (article.tags && article.tags.some(function (tag) { return tag.toLowerCase().indexOf(q) !== -1; }))
        );
      }

      function card(article) {
        return (
          '<article class="article-card" style="flex-direction:row; gap:20px; align-items:stretch;">' +
            '<div style="width:240px; flex-shrink:0;">' +
              '<img src="' + BASE + 'assets/images/' + encodeURIComponent(article.image) + '"' +
              ' alt="' + escapeHtml(article.title) + '" width="1200" height="800"' +
              ' style="width:100%; height:100%; object-fit:cover; border-radius:var(--radius-sm);" decoding="async" loading="lazy">' +
            '</div>' +
            '<div class="article-card-body" style="padding:16px 20px 16px 0;">' +
              '<div>' +
                '<span class="badge ' + escapeHtml(article.categoryBadge) + '">' + escapeHtml(article.category) + '</span>' +
                '<span style="font-size:0.75rem; color:var(--text-muted); margin-left:8px;">' + escapeHtml(article.date) + '</span>' +
              '</div>' +
              '<h2 class="article-card-title" style="font-size:1.25rem;">' +
                '<a href="' + BASE + 'articles/' + encodeURIComponent(article.slug) + '">' + escapeHtml(article.title) + '</a>' +
              '</h2>' +
              '<p class="article-card-excerpt" style="-webkit-line-clamp:2;">' + escapeHtml(article.excerpt) + '</p>' +
              '<div class="article-card-footer" style="padding-top:10px;">' +
                '<span>By ' + escapeHtml(article.author.name) + '</span>' +
                '<span>' + escapeHtml(article.readTime) + '</span>' +
              '</div>' +
            '</div>' +
          '</article>'
        );
      }

      function doSearch(updateUrl) {
        var raw = input.value.trim();
        var q = raw.toLowerCase();
        var matches = q ? ARTICLES_DATA.filter(function (a) { return matchesQuery(a, q); }) : ARTICLES_DATA;

        statsContainer.textContent = q
          ? matches.length + (matches.length === 1 ? ' result for "' : ' results for "') + raw + '"'
          : 'Showing all ' + ARTICLES_DATA.length + ' published articles.';

        if (matches.length === 0) {
          resultsContainer.innerHTML =
            '<div style="background:var(--bg-surface); padding:36px; border-radius:var(--radius-md); text-align:center; border:1px solid var(--border-subtle);">' +
              '<h2 style="color:#fff; margin-bottom:8px; font-size:1.2rem;">No matches found</h2>' +
              '<p style="color:var(--text-muted);">Try a broader keyword or browse the category pages.</p>' +
            '</div>';
        } else {
          resultsContainer.innerHTML = matches.map(card).join('');
        }

        if (updateUrl && window.history && window.history.replaceState) {
          var next = window.location.pathname + (raw ? '?q=' + encodeURIComponent(raw) : '');
          window.history.replaceState(null, '', next);
        }
      }

      var params = new URLSearchParams(window.location.search);
      var initial = params.get('q');
      if (initial) input.value = initial;

      form.addEventListener('submit', function (event) {
        event.preventDefault();
        doSearch(true);
      });

      input.addEventListener('input', function () {
        doSearch(false);
      });

      doSearch(false);
    });
  </script>"""

t = t[:start] + new_script + t[end:]
open(p, 'w', encoding='utf-8-sig', newline='').write(t)
print('search script replaced')
