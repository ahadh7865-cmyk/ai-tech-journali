import os, re, glob

changed = 0
for p in sorted(glob.glob(os.path.join('site', '**', '*.html'), recursive=True)):
    if os.sep + '_dev' + os.sep in p:
        continue
    t = open(p, encoding='utf-8-sig', newline='').read()
    o = t

    # menu toggle: icon comes from CSS, button keeps only its accessible label
    t = t.replace('aria-controls="mobile-navigation"><span aria-hidden="true">\u2630</span></button>',
                  'aria-controls="mobile-navigation"></button>')

    # back-to-top: same approach
    t = t.replace('aria-label="Back to top">\u2191</button>',
                  'aria-label="Back to top"></button>')

    if t != o:
        open(p, 'w', encoding='utf-8-sig', newline='').write(t)
        changed += 1

print('icon-only buttons normalised on', changed, 'pages')
