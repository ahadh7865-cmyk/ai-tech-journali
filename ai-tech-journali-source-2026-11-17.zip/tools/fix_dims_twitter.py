import os, re, glob
from PIL import Image

ROOT = 'site'
SITE = 'https://ahadh7865-cmyk.github.io/ai-tech-journali'

fixed = []

for p in sorted(glob.glob(os.path.join(ROOT, '**', '*.html'), recursive=True)):
    if os.sep + '_dev' + os.sep in p:
        continue
    rel = os.path.relpath(p, ROOT).replace('\\', '/')
    t = open(p, encoding='utf-8-sig', newline='').read()
    orig = t

    # 1. every img width/height must match the real file
    def fix_dims(m):
        tag = m.group(0)
        src = re.search(r'\bsrc="([^"]+)"', tag)
        if not src:
            return tag
        s = src.group(1)
        if s.startswith(('http', '/', 'data:')):
            return tag
        fp = os.path.normpath(os.path.join(os.path.dirname(p), s))
        if not os.path.exists(fp) or fp.lower().endswith('.svg'):
            return tag
        w, h = Image.open(fp).size
        tag = re.sub(r'\bwidth="\d+"', f'width="{w}"', tag)
        tag = re.sub(r'\bheight="\d+"', f'height="{h}"', tag)
        if 'width=' not in tag:
            tag = tag[:-1].rstrip() + f' width="{w}" height="{h}">'
        return tag

    t = re.sub(r'<img\b[^>]*>', fix_dims, t, flags=re.I)

    # 2. add twitter:image wherever a Twitter card exists without one
    if 'name="twitter:card"' in t and 'name="twitter:image"' not in t:
        og = re.search(r'<meta property="og:image" content="([^"]+)"', t)
        img = og.group(1) if og else SITE + '/assets/images/hero-ai-frontier.jpg'
        t = re.sub(r'(<meta name="twitter:card"[^>]*>)',
                   lambda m: m.group(1) + f'\n  <meta name="twitter:image" content="{img}">',
                   t, count=1)

    if t != orig:
        open(p, 'w', encoding='utf-8-sig', newline='').write(t)
        fixed.append(rel)

print('fixed:', len(fixed))
for f in fixed:
    print('  ' + f)
