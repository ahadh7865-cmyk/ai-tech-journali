import re

p = 'site/assets/css/style.css'
t = open(p, encoding='utf-8', newline='').read()
orig = t

# menu toggle icon drawn in CSS so the button has no visible text
t = t.replace("""  cursor: pointer;
  padding: 0;
}

.mobile-menu-toggle:hover {""", """  cursor: pointer;
  padding: 0;
}

.mobile-menu-toggle::before {
  content: "\\2630";
  font-size: 1.5rem;
  line-height: 1;
}

.mobile-menu-toggle[aria-expanded="true"]::before {
  content: "\\2715";
}

.mobile-menu-toggle:hover {""")

# back-to-top arrow drawn in CSS
t = t.replace(""".back-to-top {""", """.back-to-top::before {
  content: "\\2191";
}

.back-to-top {""", 1)

if t != orig:
    open(p, 'w', encoding='utf-8', newline='').write(t)
    print('css icon rules added')
else:
    print('no change')
