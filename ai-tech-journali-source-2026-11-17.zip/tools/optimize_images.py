import os
from PIL import Image

IMAGES = 'site/assets/images'
DROP = {'test.jpg', 'category-cybersecurity.jpg', 'category-tech.jpg'}
before = after = 0

for name in sorted(os.listdir(IMAGES)):
    if not name.lower().endswith(('.jpg', '.jpeg')):
        continue
    p = os.path.join(IMAGES, name)
    size = os.path.getsize(p)
    before += size
    if name in DROP:
        os.remove(p)
        print(f'dropped {name} ({size // 1024} KB)')
        continue

    im = Image.open(p)
    if im.mode not in ('RGB', 'L'):
        im = im.convert('RGB')

    max_w = 1200
    if im.width > max_w:
        h = round(im.height * max_w / im.width)
        im = im.resize((max_w, h), Image.LANCZOS)

    quality = 86 if name.startswith('author-') else 82
    im.save(p, 'JPEG', quality=quality, optimize=True, progressive=True)
    new = os.path.getsize(p)
    after += new
    if new < size:
        print(f'{name}: {size // 1024} KB -> {new // 1024} KB')

print(f'\ntotal {before / 1048576:.2f} MB -> {after / 1048576:.2f} MB (kept files only)')
