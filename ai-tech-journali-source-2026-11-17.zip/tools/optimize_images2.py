import os, shutil
from PIL import Image

SRC = 'extract/ai-tech-journali-main'
DST = 'site/assets/images'
DROP = {'test.jpg', 'category-cybersecurity.jpg', 'category-tech.jpg'}

before = after = 0
for name in sorted(os.listdir(SRC)):
    if not name.lower().endswith(('.jpg', '.jpeg')):
        continue
    src = os.path.join(SRC, name)
    before += os.path.getsize(src)
    if name in DROP:
        continue
    im = Image.open(src)
    if im.mode not in ('RGB', 'L'):
        im = im.convert('RGB')
    if im.width > 1200:
        im = im.resize((1200, round(im.height * 1200 / im.width)), Image.LANCZOS)
    q = 84 if name.startswith('author-') else 74
    out = os.path.join(DST, name)
    im.save(out, 'JPEG', quality=q, optimize=True, progressive=True)
    after += os.path.getsize(out)
    print(f'{name}: {os.path.getsize(src)//1024} -> {os.path.getsize(out)//1024} KB')

print(f'\n{len([n for n in os.listdir(DST) if n.endswith(".jpg")])} jpgs, {before/1048576:.2f} MB originals -> {after/1048576:.2f} MB shipped')
