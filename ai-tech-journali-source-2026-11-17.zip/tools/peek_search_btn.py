import re
t = open('index.html', encoding='utf-8-sig').read()
m = re.search(r'<button class="search-trigger-btn".*?</button>', t, re.S)
print(repr(m.group(0)))
