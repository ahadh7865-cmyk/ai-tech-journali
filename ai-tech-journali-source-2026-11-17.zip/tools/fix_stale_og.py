import os, glob

SITE = 'https://ahadh7865-cmyk.github.io/ai-tech-journali/assets/images/'
MAP = {
    'category-cybersecurity.jpg': 'cybersecurity-zero-trust.jpg',
    'category-tech.jpg': 'clean-fusion-datacenter.jpg',
}

for root in ('site', 'deploy'):
    fixed = 0
    for p in sorted(glob.glob(os.path.join(root, '**', '*.html'), recursive=True)):
        if os.sep + '_dev' + os.sep in p:
            continue
        t = open(p, encoding='utf-8-sig', newline='').read()
        o = t
        for old, new in MAP.items():
            t = t.replace(SITE + old, SITE + new)
            t = t.replace('../assets/images/' + old, '../assets/images/' + new)
        if t != o:
            open(p, 'w', encoding='utf-8-sig', newline='').write(t)
            fixed += 1
    print(root, '->', fixed, 'files updated')
