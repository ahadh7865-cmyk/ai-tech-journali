import json, sys
d = json.load(open(sys.argv[1], encoding='utf-8'))
a = d['audits']['label-content-name-mismatch']
print('score:', a['score'], '| displayValue:', a.get('displayValue'), '| scoreDisplayMode:', a['scoreDisplayMode'])
for it in a.get('details', {}).get('items', []):
    print(it['node']['snippet'])
print('final url:', d['finalDisplayedUrl'])
print('fetch time:', d['fetchTime'])
