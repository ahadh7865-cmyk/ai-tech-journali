import re
p = 'articles/agentic-ai-autonomous-workflows-2025.html'
t = open(p, encoding='utf-8-sig').read()
print(re.search(r'<a href="[^"]*index\.html" class="brand"[^>]*>', t).group(0))
print(re.search(r'<button class="search-trigger-btn"[^>]*>.*?</button>', t, re.S).group(0)[:300])
print(re.search(r'aria-label="Share on X"[^>]*>.*?</a>', t).group(0))
print(re.search(r'aria-label="Share on LinkedIn"[^>]*>.*?</a>', t).group(0))
