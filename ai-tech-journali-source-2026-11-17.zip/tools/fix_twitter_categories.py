import os, re, glob

ROOT = 'site'
SITE = 'https://ahadh7865-cmyk.github.io/ai-tech-journali'


def grab(t, pat):
    m = re.search(pat, t)
    return m.group(1) if m else ''


fixed = []
for p in sorted(glob.glob(os.path.join(ROOT, '**', '*.html'), recursive=True)):
    if os.sep + '_dev' + os.sep in p:
        continue
    rel = os.path.relpath(p, ROOT).replace('\\', '/')
    if not rel.startswith('categories/'):
        continue
    t = open(p, encoding='utf-8-sig', newline='').read()
    if 'name="twitter:card"' in t:
        continue

    title = grab(t, r'<meta property="og:title" content="([^"]*)"')
    desc = grab(t, r'<meta property="og:description" content="([^"]*)"')
    image = grab(t, r'<meta property="og:image" content="([^"]*)"') or SITE + '/assets/images/hero-ai-frontier.jpg'

    block = (
        '  <meta name="twitter:card" content="summary_large_image">\n'
        f'  <meta name="twitter:title" content="{title}">\n'
        f'  <meta name="twitter:description" content="{desc}">\n'
        f'  <meta name="twitter:image" content="{image}">\n'
    )

    m = re.search(r'[ \t]*<meta property="og:image" content="[^"]*">\r?\n', t)
    t = t[:m.end()] + block + t[m.end():]
    open(p, 'w', encoding='utf-8-sig', newline='').write(t)
    fixed.append(rel)

print('twitter blocks added:', len(fixed))
for f in fixed:
    print('  ' + f)
