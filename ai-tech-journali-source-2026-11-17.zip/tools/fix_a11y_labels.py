import os, re, glob

ROOT = 'site'
changed = 0

for p in sorted(glob.glob(os.path.join(ROOT, '**', '*.html'), recursive=True)):
    if os.sep + '_dev' + os.sep in p:
        continue
    t = open(p, encoding='utf-8-sig', newline='').read()
    o = t

    # Brand link: let the visible wordmark + logo alt be the accessible name
    t = re.sub(r'<a href="([^"]*index\.html)" class="brand" aria-label="[^"]*">',
               r'<a href="\1" class="brand">', t)

    # Search button: hide the kbd shortcut from the a11y tree, match visible text
    t = t.replace('aria-label="Open Search"', 'aria-label="Search"')
    t = re.sub(r'<kbd>Ctrl\+K</kbd>', '<kbd aria-hidden="true">Ctrl+K</kbd>', t)

    # Share buttons: visible text should be the accessible name
    t = t.replace('aria-label="Share on X">𝕏 Share</a>', 'aria-label="Share on X">Share on X</a>')
    t = t.replace('aria-label="Share on LinkedIn">in Share</a>', 'aria-label="Share on LinkedIn">Share on LinkedIn</a>')

    if t != o:
        open(p, 'w', encoding='utf-8-sig', newline='').write(t)
        changed += 1

print('a11y label fixes on', changed, 'pages')
