import json, sys
d = json.load(open(sys.argv[1], encoding='utf-8'))
for k in ['color-contrast', 'label-content-name-mismatch']:
    print('=====', k, '| score:', d['audits'][k]['score'])
    for it in d['audits'][k].get('details', {}).get('items', []):
        n = it['node']
        print(' ', n['selector'])
        print('    label:', n['nodeLabel'][:80])
        ex = (it.get('explanation') or '').replace('\n', ' ')
        print('    why:', ex[:150])
