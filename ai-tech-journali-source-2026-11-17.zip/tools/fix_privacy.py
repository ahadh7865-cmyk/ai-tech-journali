import re

p = 'site/privacy.html'
t = open(p, encoding='utf-8-sig', newline='').read()

start = t.index('    <p class="page-subtitle">Last Updated: November 10, 2025')
end = t.index('    </div>', t.index('<h2>6. Children')) + len('    </div>')

body = """    <p class="page-subtitle">Last updated: November 17, 2026</p>

    <div class="page-body">
      <p>This policy explains what <strong>AI Tech Journal</strong> does with information when you read the site. It is written to match how the site actually works: it is a static publication with no accounts, no analytics scripts, and no advertising code.</p>

      <h2>1. Information We Collect</h2>
      <ul>
        <li><strong>Hosting logs:</strong> The site is served by GitHub Pages. GitHub may process standard request data (IP address, browser type, timestamp, referring page) to deliver the site and protect its infrastructure, under the <a href="https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement" target="_blank" rel="noopener">GitHub Privacy Statement</a>. We do not operate our own log collection.</li>
        <li><strong>Newsletter:</strong> There is no signup database on this site. The subscribe button opens your own email application with a pre-addressed message. If you send it, your email address and message are handled by the email provider that hosts the publication mailbox.</li>
        <li><strong>Contact messages:</strong> The contact form does not transmit anything to a server. It builds a draft in your email client. Nothing is stored by this website.</li>
      </ul>

      <h2>2. Cookies and Local Storage</h2>
      <p>This site sets no cookies and writes no local storage. If that changes (for example, if analytics or advertising are added), this policy will be updated before the change goes live.</p>

      <h2>3. Advertising</h2>
      <p>This site currently displays no third-party advertising and no affiliate links. Any future advertising or sponsorship will be labelled, and this section will be updated with the relevant cookie and opt-out information.</p>

      <h2>4. GDPR Rights</h2>
      <p>If you are in the European Economic Area, you have the right to access, correct, delete, or restrict processing of personal data we hold about you, and the right to data portability. Because the site itself stores nothing, the only personal data we could hold is email you have chosen to send us.</p>
      <p>To exercise these rights, write to <a href="mailto:__CONTACT_EMAIL__?subject=Privacy%20request">__CONTACT_EMAIL__</a>.</p>

      <h2>5. CCPA Rights</h2>
      <p>California residents may request disclosure or deletion of personal information, and may request that a business not sell their personal information. <strong>AI Tech Journal does not sell personal information.</strong></p>

      <h2>6. Children's Privacy</h2>
      <p>AI Tech Journal does not knowingly collect personal information from children under 13. If you believe a child has sent us personal information, contact us and we will delete it.</p>

      <h2>7. Changes to This Policy</h2>
      <p>Material changes will be reflected in the date at the top of this page.</p>
    </div>"""

t = t[:start] + body + t[end:]
open(p, 'w', encoding='utf-8-sig', newline='').write(t)
print('privacy updated')
