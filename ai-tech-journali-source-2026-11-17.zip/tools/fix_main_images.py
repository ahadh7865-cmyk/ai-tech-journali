import os, re
from PIL import Image

for f in os.listdir('articles'):
    if not f.endswith('.html'):
        continue
    p = os.path.join('articles', f)
    t = open(p, encoding='utf-8-sig', newline='').read()
    m = re.search(r'<figure class="article-main-image">\s*<img src="\.\./assets/images/([^"]+)"[^>]*>', t)
    if not m:
        print('no main image', p)
        continue
    name = m.group(1)
    w, h = Image.open(os.path.join('assets', 'images', name)).size
    tag = m.group(0)
    new = re.sub(r'width="\d+" height="\d+"', f'width="{w}" height="{h}"', tag)
    t = t.replace(tag, new, 1)
    open(p, 'w', encoding='utf-8-sig', newline='').write(t)
    print(p, name, w, h)
