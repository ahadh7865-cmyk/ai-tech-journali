import os, re, glob

changed = []

for p in sorted(glob.glob(os.path.join('site', '**', '*.html'), recursive=True)):
    if os.sep + '_dev' + os.sep in p:
        continue
    t = open(p, encoding='utf-8-sig', newline='').read()
    o = t

    # decorative magnifier inside the header search button
    t = t.replace('<span>\U0001F50D</span>\n            <span>Search</span>',
                  '<span aria-hidden="true">\U0001F50D</span>\n            <span>Search</span>')
    t = t.replace('<span>\U0001F50D</span>\r\n            <span>Search</span>',
                  '<span aria-hidden="true">\U0001F50D</span>\r\n            <span>Search</span>')
    t = t.replace('<span class="info-card-icon">', '<span class="info-card-icon" aria-hidden="true">')

    if t != o:
        open(p, 'w', encoding='utf-8-sig', newline='').write(t)
        changed.append(os.path.relpath(p, 'site'))

print('icon spans marked decorative on', len(changed), 'pages')
