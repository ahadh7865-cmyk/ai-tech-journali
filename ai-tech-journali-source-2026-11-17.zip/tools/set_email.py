#!/usr/bin/env python3
"""Replace the __CONTACT_EMAIL__ placeholder with a real address.

Usage:
    python set_email.py you@example.com
    python set_email.py you@example.com ../site

The script rewrites every .html and .js file under the target folder and
reports how many replacements it made. Re-running with another address is
safe: it only matches the placeholder token.
"""
import os
import re
import sys

TOKEN = "__CONTACT_EMAIL__"
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2

    email = sys.argv[1].strip()
    root = os.path.abspath(sys.argv[2] if len(sys.argv) > 2 else ".")

    if not EMAIL_RE.match(email):
        print(f"Not a valid email address: {email!r}")
        return 2

    if not os.path.isdir(root):
        print(f"Folder not found: {root}")
        return 2

    files = 0
    hits = 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in {".git", "_dev", "tools"}]
        for name in filenames:
            if not name.lower().endswith((".html", ".js")):
                continue
            path = os.path.join(dirpath, name)
            with open(path, encoding="utf-8-sig", newline="") as fh:
                text = fh.read()
            count = text.count(TOKEN)
            if not count:
                continue
            text = text.replace(TOKEN, email)
            with open(path, "w", encoding="utf-8-sig", newline="") as fh:
                fh.write(text)
            files += 1
            hits += count
            print(f"  {os.path.relpath(path, root)}: {count}")

    print(f"\nReplaced {hits} placeholder(s) in {files} file(s) with {email}")
    if hits == 0:
        print("Nothing to replace. Either the address is already set, or the folder is wrong.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
