import re, sys
p = 'articles/agentic-ai-autonomous-workflows-2025.html'
t = open(p, encoding='utf-8-sig').read()
out = []
out.append('TITLE: ' + repr(re.search(r'<title>(.*?)</title>', t).group(1)))
m = re.search(r'<figure class="article-main-image">.*?</figure>', t, re.S)
out.append('FIGURE:\n' + m.group(0))
out.append('TABLE CELLS: ' + repr([l.strip() for l in t.splitlines() if '<td>' in l][:6]))
out.append('TOGGLE: ' + repr(re.search(r'<button class="mobile-menu-toggle"[^>]*>.*?</button>', t).group(0)))
out.append('SHARE: ' + repr(re.search(r'aria-label="Share on X"[^>]*>.*?</a>', t).group(0)))
js = open('assets/js/main.js', encoding='utf-8').read()
out.append('MAIN.JS exists: %d bytes' % len(js))
open('../tools/inspect_out.txt', 'w', encoding='utf-8').write('\n\n'.join(out))
print('written')
