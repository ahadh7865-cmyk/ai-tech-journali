import os, re, glob

changed = 0
for p in sorted(glob.glob(os.path.join('site', '**', '*.html'), recursive=True)):
    if os.sep + '_dev' + os.sep in p:
        continue
    t = open(p, encoding='utf-8-sig', newline='').read()
    o = t

    t = t.replace('aria-controls="mobile-navigation">\u2630</button>',
                  'aria-controls="mobile-navigation"><span aria-hidden="true">\u2630</span></button>')

    if t != o:
        open(p, 'w', encoding='utf-8-sig', newline='').write(t)
        changed += 1

print('menu icon wrapped on', changed, 'pages')
