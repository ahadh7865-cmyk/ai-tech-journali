import os, re, glob

SITE = 'https://ahadh7865-cmyk.github.io/ai-tech-journali'
TODAY = '2026-11-17'

urls = []


def add(path, lastmod, priority='0.7'):
    urls.append((path, lastmod, priority))


add('', TODAY, '1.0')
for name in ['about.html', 'contact.html', 'privacy.html', 'terms.html', 'disclaimer.html']:
    add(name, TODAY, '0.4')

# search.html is intentionally excluded: robots.txt disallows it.

add('categories/', TODAY, '0.8')
for p in sorted(glob.glob('site/categories/*.html')):
    name = os.path.basename(p)
    if name == 'index.html':
        continue
    add('categories/' + name, TODAY, '0.7')

for p in sorted(glob.glob('site/articles/*.html')):
    name = os.path.basename(p)
    t = open(p, encoding='utf-8-sig').read()
    m = re.search(r'article:published_time" content="([\d-]+)"', t)
    add('articles/' + name, m.group(1) if m else TODAY, '0.9')

lines = ['<?xml version="1.0" encoding="UTF-8"?>',
         '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
for path, lastmod, priority in urls:
    lines.append('  <url>')
    lines.append(f'    <loc>{SITE}/{path}</loc>')
    lines.append(f'    <lastmod>{lastmod}</lastmod>')
    lines.append(f'    <priority>{priority}</priority>')
    lines.append('  </url>')
lines.append('</urlset>')
open('site/sitemap.xml', 'w', encoding='utf-8', newline='\n').write('\n'.join(lines) + '\n')

robots = f"""User-agent: *
Allow: /

# Search-result pages add no indexable content
Disallow: /search.html
Disallow: /404.html

Sitemap: {SITE}/sitemap.xml
"""
open('site/robots.txt', 'w', encoding='utf-8', newline='\n').write(robots)

print(f'sitemap: {len(urls)} urls')
