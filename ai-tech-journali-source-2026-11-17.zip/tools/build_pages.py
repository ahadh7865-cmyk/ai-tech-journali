import os, re

SITE = "https://ahadh7865-cmyk.github.io/ai-tech-journali"
BASE = "/ai-tech-journali/"

about = open('site/about.html', encoding='utf-8-sig', newline='').read()
index = open('site/index.html', encoding='utf-8-sig', newline='').read()

# ---------------------------------------------------------------- 404 page
p404 = about
head_start = p404.index('<title>')
head_end = p404.index('<link rel="icon"')
p404 = p404[:head_start] + """<title>Page not found \u2014 AI Tech Journal</title>
  <meta name="description" content="The page you requested does not exist. Browse AI Tech Journal's desks or search the archive.">
  <meta name="robots" content="noindex, follow">
  <link rel="canonical" href="%s/404.html">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="AI Tech Journal">
  <meta property="og:url" content="%s/404.html">
  <meta property="og:title" content="Page not found \u2014 AI Tech Journal">
  <meta property="og:description" content="The page you requested does not exist. Browse our desks or search the archive.">
  <meta property="og:image" content="%s/assets/images/hero-ai-frontier.jpg">
  <meta name="twitter:card" content="summary">
  <meta name="twitter:title" content="Page not found \u2014 AI Tech Journal">
  <meta name="twitter:description" content="The page you requested does not exist.">
  """ % (SITE, SITE, SITE) + p404[head_end:]

main_start = p404.index('<main class="page-wrapper container">')
main_end = p404.index('</main>') + len('</main>')
p404_main = """<main class="page-wrapper container">
    <div style="text-align:center; padding:48px 0 24px;">
      <p style="font-size:0.85rem; letter-spacing:0.18em; text-transform:uppercase; color:var(--accent-cyan); font-weight:700;">Error 404</p>
      <h1 class="page-title" style="margin-top:8px;">That page isn&#39;t here</h1>
      <p class="page-subtitle" style="max-width:560px; margin:0 auto;">The link may be outdated, or the article may have moved. Everything we publish lives under a desk below.</p>
      <div style="display:flex; gap:12px; justify-content:center; flex-wrap:wrap; margin-top:28px;">
        <a href="%s" class="form-submit-btn" style="text-decoration:none; display:inline-block;">Back to the homepage</a>
        <a href="%scategories/" class="subscribe-btn-sm" style="text-decoration:none; display:inline-block; padding:12px 22px;">Browse all categories</a>
      </div>
    </div>

    <div class="page-body">
      <h2>Popular desks</h2>
      <div class="articles-grid" style="margin-top:20px;">
        <article class="article-card">
          <div class="article-card-body">
            <span class="badge badge-ai">Artificial Intelligence</span>
            <h3 class="article-card-title"><a href="%scategories/artificial-intelligence.html">Foundation models, agents, and multimodal research</a></h3>
          </div>
        </article>
        <article class="article-card">
          <div class="article-card-body">
            <span class="badge badge-future">Future Technology</span>
            <h3 class="article-card-title"><a href="%scategories/future-technology.html">Quantum computing, robotics, and neuromorphic hardware</a></h3>
          </div>
        </article>
        <article class="article-card">
          <div class="article-card-body">
            <span class="badge badge-cybersecurity">Cybersecurity</span>
            <h3 class="article-card-title"><a href="%scategories/cybersecurity.html">Zero trust, identity fraud, and deepfake defense</a></h3>
          </div>
        </article>
      </div>
      <p style="margin-top:28px;">Still stuck? <a href="%ssearch.html">Search the archive</a> or <a href="%scontact.html">contact the editorial desk</a>.</p>
    </div>
  </main>""" % (BASE, BASE, BASE, BASE, BASE, BASE, BASE)

p404 = p404[:main_start] + p404_main + p404[main_end:]

# absolute paths, because a 404 can be served from any directory depth
p404 = re.sub(r'(href|src)="\./', lambda m: m.group(1) + '="' + BASE, p404)
open('site/404.html', 'w', encoding='utf-8-sig', newline='').write(p404)

# ---------------------------------------------------------------- categories index
cats = index
head_start = cats.index('<title>')
head_end = cats.index('<link rel="icon"')
cats = cats[:head_start] + """<title>All Desks &amp; Categories \u2014 AI Tech Journal</title>
  <meta name="description" content="Browse every AI Tech Journal desk: artificial intelligence, AI tools, software, cybersecurity, future technology, gadgets, business, and more.">
  <link rel="canonical" href="%s/categories/">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="AI Tech Journal">
  <meta property="og:url" content="%s/categories/">
  <meta property="og:title" content="All Desks &amp; Categories \u2014 AI Tech Journal">
  <meta property="og:description" content="Browse every AI Tech Journal desk.">
  <meta property="og:image" content="%s/assets/images/hero-ai-frontier.jpg">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="All Desks &amp; Categories \u2014 AI Tech Journal">
  <meta name="twitter:description" content="Browse every AI Tech Journal desk.">
  <meta name="twitter:image" content="%s/assets/images/hero-ai-frontier.jpg">
  """ % (SITE, SITE, SITE, SITE) + cats[head_end:]

# replace index's JSON-LD with a CollectionPage
cats = re.sub(r'<script type="application/ld\+json">.*?</script>',
              '''<script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": "All Desks & Categories",
    "url": "%s/categories/",
    "publisher": {
      "@type": "NewsMediaOrganization",
      "name": "AI Tech Journal",
      "url": "%s/"
    }
  }
  </script>''' % (SITE, SITE), cats, count=1, flags=re.S)

main_start = cats.index('<main class="container">')
main_end = cats.index('</main>') + len('</main>')
cards = [
    ("artificial-intelligence.html", "category-ai.jpg", "Artificial Intelligence", "badge-ai",
     "Foundation models, agentic systems, multimodal research, and the architecture of frontier AI.", 3),
    ("ai-tools.html", "category-tools.jpg", "AI Tools", "badge-tools",
     "Hands-on evaluation of local runtimes, coding agents, and production-ready developer utilities.", 1),
    ("software.html", "category-software.jpg", "Software", "badge-software",
     "WebAssembly, edge inference, and how automated code generation is reshaping engineering.", 2),
    ("cybersecurity.html", "cybersecurity-zero-trust.jpg", "Cybersecurity", "badge-cybersecurity",
     "Zero trust, machine identity, deepfake fraud, and biometric defenses for enterprise networks.", 2),
    ("future-technology.html", "category-future.jpg", "Future Technology", "badge-future",
     "Quantum error correction, humanoid robotics, and computing beyond classical silicon.", 2),
    ("technology.html", "clean-fusion-datacenter.jpg", "Technology", "badge-tech",
     "Data-center power, neuromorphic chips, and the physical layer beneath modern AI.", 2),
    ("gadgets.html", "category-gadgets.jpg", "Gadgets", "badge-gadgets",
     "Neural-interface wearables, spatial computing hardware, and consumer robotics.", 1),
    ("business-startups.html", "category-business.jpg", "Business &amp; Startups", "badge-business",
     "Venture funding shifts, vertical AI foundries, and the economics of synthetic labor.", 1),
]
card_html = []
for slug, img, name, badge, desc, count in cards:
    card_html.append(f"""        <article class="article-card">
          <div class="article-card-thumb">
            <img src="../assets/images/{img}" alt="{name}" width="1200" height="800" loading="lazy" decoding="async">
          </div>
          <div class="article-card-body">
            <span class="badge {badge}">{name}</span>
            <h2 class="article-card-title" style="font-size:1.2rem;"><a href="{slug}">{name}</a></h2>
            <p class="article-card-excerpt">{desc}</p>
            <div class="article-card-footer">
              <span>{count} article{'s' if count != 1 else ''}</span>
              <span><a href="{slug}">Open desk \u2192</a></span>
            </div>
          </div>
        </article>""")

cats_main = """<main class="container">
    <section class="page-wrapper" style="padding-top:36px;">
      <p style="font-size:0.8rem; letter-spacing:0.16em; text-transform:uppercase; color:var(--accent-cyan); font-weight:700;">Editorial index</p>
      <h1 class="page-title">All Desks &amp; Categories</h1>
      <p class="page-subtitle">Every article on AI Tech Journal is filed under one of these eight desks. Start anywhere.</p>
    </section>

    <section class="section-wrapper">
      <div class="articles-grid">
%s
      </div>
    </section>
  </main>""" % "\n".join(card_html)
cats = cats[:main_start] + cats_main + cats[main_end:]

# this page lives one level down
cats = re.sub(r'(href|src)="\./', lambda m: m.group(1) + '="../', cats)
cats = cats.replace('<body>', '<body data-subfolder="true">')
open('site/categories/index.html', 'w', encoding='utf-8-sig', newline='').write(cats)

print('404.html and categories/index.html written')
