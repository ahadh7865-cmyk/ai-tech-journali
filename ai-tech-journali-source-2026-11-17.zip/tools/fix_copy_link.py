import os, re, glob

DG = '\U0001F517'  # 🔗
SVG = ('<svg aria-hidden="true" focusable="false" width="14" height="14" viewBox="0 0 24 24" '
       'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">'
       '<path d="M10 13a5 5 0 0 0 7 0l2-2a5 5 0 0 0-7-7l-1 1"></path>'
       '<path d="M14 11a5 5 0 0 0-7 0l-2 2a5 5 0 0 0 7 7l1-1"></path></svg>')

changed = 0
for p in sorted(glob.glob(os.path.join('site', '**', '*.html'), recursive=True)):
    if os.sep + '_dev' + os.sep in p:
        continue
    t = open(p, encoding='utf-8-sig', newline='').read()
    o = t

    t = t.replace(DG + ' Copy Link', SVG + ' Copy Link')
    t = t.replace('aria-label="Copy article link"', 'aria-label="Copy Link"')

    if t != o:
        open(p, 'w', encoding='utf-8-sig', newline='').write(t)
        changed += 1

print('copy-link fixed on', changed, 'pages')
