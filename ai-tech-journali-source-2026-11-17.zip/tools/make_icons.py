import shutil, os
from PIL import Image, ImageDraw, ImageFont

shutil.copyfile('site/assets/images/logo.svg', 'site/favicon.svg')

size = 180
img = Image.new('RGBA', (size, size), (13, 17, 28, 255))
d = ImageDraw.Draw(img)
# rounded background
d.rounded_rectangle([0, 0, size - 1, size - 1], radius=40, fill=(13, 17, 28, 255),
                    outline=(255, 255, 255, 25), width=2)
# gradient-ish chevron "A"
try:
    font = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 118)
except Exception:
    font = ImageFont.load_default()
text = "A"
bbox = d.textbbox((0, 0), text, font=font)
w = bbox[2] - bbox[0]
h = bbox[3] - bbox[1]
x = (size - w) / 2 - bbox[0]
y = (size - h) / 2 - bbox[1] - 6
d.text((x, y), text, font=font, fill=(0, 240, 255, 255))
img.save('site/apple-touch-icon.png', optimize=True)
print('favicon + apple-touch-icon written')
