import os, re, json, glob, html, sys
from PIL import Image
from urllib.parse import urlparse

ROOT = sys.argv[1] if len(sys.argv) > 1 else 'site'
SITE = 'https://ahadh7865-cmyk.github.io/ai-tech-journali'
BAD_TEXT = ['aitechjournal.com', 'ISSN', '85,000', 'Updated Hourly', 'Live Intel',
            'Published Daily', 'Founded in 2024', 'Silicon Valley, CA',
            '24/7/365', '800-555', 'Data Protection Officer']
pages = []
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in {'_dev'}]
    for f in fn:
        if f.endswith('.html'):
            pages.append(os.path.join(dp, f))
pages.sort()

problems = []
email_hits = 0
jsonld_count = 0

for p in pages:
    rel = os.path.relpath(p, ROOT).replace('\\', '/')
    t = open(p, encoding='utf-8-sig').read()

    # leftover fake claims / placeholder leaks in visible text
    visible = re.sub(r'<script.*?</script>', ' ', t, flags=re.S)
    visible = re.sub(r'<[^>]+>', ' ', visible)
    for bad in BAD_TEXT:
        if bad.lower() in visible.lower():
            problems.append(f'{rel}: leftover text "{bad}"')

    # tokens only inside mailto/href (or as visible link text next to mailto)
    email_hits += t.count('__CONTACT_EMAIL__')
    for m in re.finditer(r'__CONTACT_EMAIL__', t):
        window = t[max(0, m.start() - 60):m.end() + 60]
        if 'mailto:' not in window and 'action=' not in window:
            problems.append(f'{rel}: token outside mailto context -> ...{window}...')

    # JSON-LD validity + absolute urls
    for block in re.findall(r'<script type="application/ld\+json">(.*?)</script>', t, re.S):
        jsonld_count += 1
        try:
            data = json.loads(block)
        except Exception as e:
            problems.append(f'{rel}: invalid JSON-LD: {e}')
            continue
        raw = json.dumps(data)
        for u in re.findall(r'"(https?://[^"]+)"', raw):
            if u.startswith('https://schema.org'):
                continue
            if not u.startswith(SITE):
                problems.append(f'{rel}: JSON-LD foreign url {u}')
        for u in re.findall(r'"(\.\.?/[^"]*)"', raw):
            problems.append(f'{rel}: JSON-LD relative url {u}')

    # canonical / og / twitter absolute
    for attr, pat in [
        ('canonical', r'<link rel="canonical" href="([^"]*)"'),
        ('og:url', r'<meta property="og:url" content="([^"]*)"'),
        ('og:image', r'<meta property="og:image" content="([^"]*)"'),
        ('twitter:image', r'<meta name="twitter:image" content="([^"]*)"'),
    ]:
        m = re.search(pat, t)
        if not m:
            problems.append(f'{rel}: missing {attr}')
        elif not m.group(1).startswith(SITE):
            problems.append(f'{rel}: {attr} not absolute ({m.group(1)})')

    # image dimensions match real files
    for tag in re.findall(r'<img\b[^>]*>', t, re.I):
        src = re.search(r'\bsrc="([^"]+)"', tag)
        w = re.search(r'\bwidth="(\d+)"', tag)
        h = re.search(r'\bheight="(\d+)"', tag)
        if not (src and w and h):
            continue
        s = src.group(1)
        if s.startswith('http') or s.startswith('/'):
            continue
        if '+' in s or 'encodeURIComponent' in s or "'" in s:
            continue  # JS-built src, not a static path
        fp = os.path.normpath(os.path.join(os.path.dirname(p), s))
        if not os.path.exists(fp):
            problems.append(f'{rel}: image missing on disk {s}')
            continue
        if fp.endswith('.svg'):
            continue
        real = Image.open(fp).size
        got = (int(w.group(1)), int(h.group(1)))
        if real != got:
            problems.append(f'{rel}: {os.path.basename(s)} dims {got} != {real}')

print(f'pages: {len(pages)}  json-ld blocks: {jsonld_count}  email tokens: {email_hits}')
print(f'problems: {len(problems)}')
for x in problems:
    print('  ' + x)
