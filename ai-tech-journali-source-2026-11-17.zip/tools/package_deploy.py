#!/usr/bin/env python3
"""Build a deploy-ready folder and ZIP from site/, with the contact email applied.

Usage:
    python package_deploy.py you@example.com

Output:
    deploy/                          upload-ready folder (assets, articles, categories, pages)
    dist/ai-tech-journali-deploy.zip  same contents, zipped

The script refuses to build if the email is invalid and warns if any
__CONTACT_EMAIL__ placeholder survives.
"""
import os
import re
import shutil
import sys
import zipfile
from datetime import date

TOKEN = "__CONTACT_EMAIL__"
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
SITE = os.path.join(ROOT, "site")
DEPLOY = os.path.join(ROOT, "deploy")
DIST = os.path.join(ROOT, "dist")

SKIP_DIRS = {"_dev", "tools", ".git", "preview", "dist"}


def ignore(_dir, names):
    return [n for n in names if n in SKIP_DIRS]


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2

    email = sys.argv[1].strip()
    if not EMAIL_RE.match(email):
        print(f"Not a valid email address: {email!r}")
        return 2

    if os.path.isdir(DEPLOY):
        shutil.rmtree(DEPLOY)
    shutil.copytree(SITE, DEPLOY, ignore=ignore)

    files = hits = 0
    for dirpath, dirnames, filenames in os.walk(DEPLOY):
        dirnames[:] = [d for d in dirnames if d not in {"_dev", "tools"}]
        for name in filenames:
            if not name.lower().endswith((".html", ".js")):
                continue
            path = os.path.join(dirpath, name)
            with open(path, encoding="utf-8-sig", newline="") as fh:
                text = fh.read()
            if TOKEN not in text:
                continue
            hits += text.count(TOKEN)
            with open(path, "w", encoding="utf-8-sig", newline="") as fh:
                fh.write(text.replace(TOKEN, email))
            files += 1

    leftover = 0
    for dirpath, dirnames, filenames in os.walk(DEPLOY):
        for name in filenames:
            if name.lower().endswith((".html", ".js")):
                text = open(os.path.join(dirpath, name), encoding="utf-8-sig").read()
                leftover += text.count(TOKEN)

    os.makedirs(DIST, exist_ok=True)
    zip_path = os.path.join(DIST, f"ai-tech-journali-deploy-{date.today().isoformat()}.zip")
    if os.path.exists(zip_path):
        os.remove(zip_path)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for dirpath, dirnames, filenames in os.walk(DEPLOY):
            dirnames[:] = sorted(dirnames)
            for name in sorted(filenames):
                full = os.path.join(dirpath, name)
                z.write(full, os.path.relpath(full, DEPLOY).replace("\\", "/"))

    size = os.path.getsize(zip_path) / 1048576
    print(f"email applied: {hits} replacement(s) in {files} file(s) -> {email}")
    print(f"deploy folder: {DEPLOY}")
    print(f"zip: {zip_path} ({size:.2f} MB)")
    if leftover:
        print(f"WARNING: {leftover} placeholder(s) still present; do not upload.")
        return 1
    print("No placeholders left. Ready to upload the contents of deploy/ (or the zip).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
