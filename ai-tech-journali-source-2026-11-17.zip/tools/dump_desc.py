import re, glob, os, html
for f in sorted(glob.glob('articles/*.html')):
    t = open(f, encoding='utf-8-sig').read()
    d = re.search(r'<meta name="description" content="([^"]*)"', t)
    v = html.unescape(d.group(1)) if d else 'NONE'
    print(f"{os.path.basename(f)}\n    {len(v)} | {v}")
