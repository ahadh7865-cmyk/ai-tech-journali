import os, re, glob

SVG = ('<svg aria-hidden="true" focusable="false" width="16" height="16" viewBox="0 0 24 24" '
       'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">'
       '<circle cx="11" cy="11" r="7"></circle><path d="M20 20l-3.5-3.5"></path></svg>')

changed = 0
for p in sorted(glob.glob(os.path.join('site', '**', '*.html'), recursive=True)):
    if os.sep + '_dev' + os.sep in p:
        continue
    t = open(p, encoding='utf-8-sig', newline='').read()
    o = t

    t = t.replace('<button class="search-trigger-btn" type="button" aria-label="Search">',
                  '<button class="search-trigger-btn" type="button">')
    t = t.replace('<span aria-hidden="true">\U0001F50D</span>\n            <span>Search</span>',
                  SVG + '\n            <span>Search</span>')
    t = t.replace('<span aria-hidden="true">\U0001F50D</span>\r\n            <span>Search</span>',
                  SVG + '\r\n            <span>Search</span>')

    if t != o:
        open(p, 'w', encoding='utf-8-sig', newline='').write(t)
        changed += 1

print('search button icon swapped on', changed, 'pages')
