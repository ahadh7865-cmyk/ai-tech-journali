#!/usr/bin/env python3
"""Local site integrity checker: internal links, assets, anchors, SEO fields."""
import os, re, sys, json, html
from urllib.parse import urlparse, unquote
from collections import defaultdict, Counter

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else "site")

ATTR_RE = re.compile(r'''(?:href|src|srcset|content)\s*=\s*["']([^"']+)["']''', re.I)
HREF_RE = re.compile(r'''<a\b[^>]*?href\s*=\s*["']([^"']+)["']''', re.I | re.S)
SRC_RE = re.compile(r'''(?:src|srcset)\s*=\s*["']([^"']+)["']''', re.I)
ID_RE = re.compile(r'''\bid\s*=\s*["']([^"']+)["']''', re.I)
TITLE_RE = re.compile(r'''<title>(.*?)</title>''', re.I | re.S)
CANON_RE = re.compile(r'''<link[^>]+rel=["']canonical["'][^>]*href=["']([^"']+)["']''', re.I)
DESC_RE = re.compile(r'''<meta[^>]+name=["']description["'][^>]*content=["']([^"']*)["']''', re.I)
H_RE = re.compile(r'''<h([1-6])\b''', re.I)
IMG_RE = re.compile(r'''<img\b[^>]*>''', re.I)
JSONLD_RE = re.compile(r'''<script[^>]+type=["']application/ld\+json["'][^>]*>(.*?)</script>''', re.I | re.S)

def walk_html():
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in {".git", "_dev"}]
        for f in filenames:
            if f.lower().endswith(".html"):
                yield os.path.join(dirpath, f)

pages = sorted(walk_html())
rel = lambda p: os.path.relpath(p, ROOT).replace("\\", "/")

ids_by_page = {}
for p in pages:
    txt = open(p, encoding="utf-8", errors="replace").read()
    ids_by_page[p] = set(ID_RE.findall(txt))

broken = []
external = Counter()
checked = 0
per_page = defaultdict(list)

def check(page, raw, kind):
    global checked
    raw = html.unescape(raw.strip())
    if not raw or raw.startswith(("data:", "javascript:", "mailto:", "tel:")):
        return
    if raw.startswith("#"):
        frag = unquote(raw[1:])
        if frag and frag not in ids_by_page[page]:
            broken.append((rel(page), raw, kind, "missing anchor"))
        return
    u = urlparse(raw)
    if u.scheme in ("http", "https") or raw.startswith("//"):
        external[u.netloc] += 1
        return
    if u.scheme:
        return
    target = unquote(u.path)
    if not target:
        return
    if target.startswith("/ai-tech-journali/"):
        target = target[len("/ai-tech-journali/"):] or "."
    elif target == "/ai-tech-journali":
        target = "."
    checked += 1
    base = os.path.dirname(page)
    full = os.path.normpath(os.path.join(base, target.lstrip("/") if not target.startswith("/") else target[1:]))
    if os.path.isdir(full):
        cand = os.path.join(full, "index.html")
        if os.path.exists(cand):
            full = cand
        else:
            broken.append((rel(page), raw, kind, "directory without index.html"))
            return
    if not os.path.exists(full):
        # allow pretty URLs /articles/foo -> foo.html
        if os.path.exists(full + ".html"):
            full = full + ".html"
        else:
            broken.append((rel(page), raw, kind, "missing file"))
            return
    if u.fragment and full.lower().endswith(".html"):
        if unquote(u.fragment) not in ids_by_page.get(full, set()):
            broken.append((rel(page), raw, kind, "missing anchor"))

for p in pages:
    txt = open(p, encoding="utf-8", errors="replace").read()
    for m in HREF_RE.finditer(txt):
        check(p, m.group(1), "href")
    for m in SRC_RE.finditer(txt):
        v = m.group(1)
        if "," in v and p.lower().endswith(".html") and v.strip().startswith(("http", "/")):
            pass
        for part in (v.split(",") if " " in v and not v.startswith("http") else [v]):
            check(p, part.strip().split(" ")[0], "src")
    for m in re.finditer(r'''<link\b[^>]*>''', txt, re.I):
        tag = m.group(0)
        hm = re.search(r'''href\s*=\s*["']([^"']+)["']''', tag, re.I)
        if hm:
            check(p, hm.group(1), "link")

print(f"Pages scanned: {len(pages)}  internal refs checked: {checked}")
print(f"Broken internal refs: {len(broken)}")
for page, raw, kind, why in broken:
    print(f"  [{why}] {page} -> {raw} ({kind})")

print("\nExternal hosts (not fetched):")
for h, c in external.most_common():
    print(f"  {h}: {c}")

print("\n--- SEO / structure per page ---")
problems = 0
for p in pages:
    txt = open(p, encoding="utf-8", errors="replace").read()
    r = rel(p)
    title = TITLE_RE.search(txt)
    title = html.unescape(title.group(1).strip()) if title else ""
    canon = CANON_RE.search(txt)
    canon = canon.group(1) if canon else ""
    desc = DESC_RE.search(txt)
    desc = html.unescape(desc.group(1)) if desc else ""
    hs = [int(x) for x in H_RE.findall(txt)]
    issues = []
    if not title:
        issues.append("no title")
    elif len(title) > 60:
        issues.append(f"title {len(title)} chars")
    if not canon:
        issues.append("no canonical")
    elif not canon.startswith("http"):
        issues.append("relative canonical")
    if len(desc) > 160:
        issues.append(f"desc {len(desc)} chars")
    if not desc:
        issues.append("no meta description")
    if hs:
        if hs[0] != 1 and "index.html" not in r:
            issues.append(f"first heading h{hs[0]}")
        prev = 0
        for h in hs:
            if prev and h > prev + 1:
                issues.append(f"heading jump h{prev}->h{h}")
                break
            prev = h
    for j in JSONLD_RE.findall(txt):
        try:
            json.loads(j)
        except Exception as e:
            issues.append(f"invalid JSON-LD ({str(e)[:40]})")
    imgs = IMG_RE.findall(txt)
    no_dim = [i for i in imgs if not (re.search(r'''\bwidth\s*=''', i) and re.search(r'''\bheight\s*=''', i))]
    if no_dim:
        issues.append(f"{len(no_dim)}/{len(imgs)} img without width+height")
    if issues:
        problems += 1
        print(f"  {r}: " + "; ".join(issues))
print(f"\nPages with SEO/structure issues: {problems}")

# dupes
print("\n--- duplicate files (sha256) ---")
import hashlib
seen = defaultdict(list)
for dirpath, dirnames, filenames in os.walk(ROOT):
    for f in filenames:
        fp = os.path.join(dirpath, f)
        h = hashlib.sha256(open(fp, "rb").read()).hexdigest()
        seen[h].append(fp)
for h, files in seen.items():
    if len(files) > 1:
        print("  " + " == ".join(rel(f) for f in files))

# orphans (files never referenced)
print("\n--- unreferenced files ---")
allrefs = set()
for p in pages:
    txt = open(p, encoding="utf-8", errors="replace").read()
    for m in ATTR_RE.finditer(txt):
        v = html.unescape(m.group(1)).strip()
        u = urlparse(v)
        if u.scheme or v.startswith(("#", "//")):
            continue
        t = unquote(u.path)
        if not t:
            continue
        allrefs.add(os.path.normpath(os.path.join(os.path.dirname(p), t.lstrip("/"))).lower())
        allrefs.add(os.path.normpath(os.path.join(ROOT, t.lstrip("/")).replace("\\", "/")).lower())
for dirpath, dirnames, filenames in os.walk(ROOT):
    for f in filenames:
        fp = os.path.normpath(os.path.join(dirpath, f)).lower()
        if f.lower().endswith(".html") and rel(fp).endswith("index.html") and os.path.dirname(fp) != os.path.normpath(ROOT).lower():
            continue
        if fp not in allrefs:
            print("  " + rel(os.path.join(dirpath, f)))
