#!/usr/bin/env python3
"""Phase 2-6 repair pass for the AI Tech Journal deploy bundle."""
import os, re, glob, json
from urllib.parse import urljoin, urlparse

SITE = "https://ahadh7865-cmyk.github.io/ai-tech-journali"
EMAIL = "__CONTACT_EMAIL__"
ROOT = os.path.abspath("site")

TITLES = {
    "index.html": "AI Tech Journal \u2014 Frontier AI & Technology News",
    "about.html": "About AI Tech Journal \u2014 Mission & Standards",
    "contact.html": "Contact the AI Tech Journal Newsroom",
    "privacy.html": "Privacy Policy \u2014 AI Tech Journal",
    "terms.html": "Terms of Use \u2014 AI Tech Journal",
    "disclaimer.html": "Editorial Disclaimer \u2014 AI Tech Journal",
    "search.html": "Search \u2014 AI Tech Journal",
    "categories/ai-tools.html": "AI Tools \u2014 AI Tech Journal",
    "categories/artificial-intelligence.html": "Artificial Intelligence \u2014 AI Tech Journal",
    "categories/business-startups.html": "Business & Startups \u2014 AI Tech Journal",
    "categories/cybersecurity.html": "Cybersecurity \u2014 AI Tech Journal",
    "categories/future-technology.html": "Future Technology \u2014 AI Tech Journal",
    "categories/gadgets.html": "Gadgets \u2014 AI Tech Journal",
    "categories/software.html": "Software \u2014 AI Tech Journal",
    "categories/technology.html": "Technology \u2014 AI Tech Journal",
    "articles/agentic-ai-autonomous-workflows-2025.html": "Agentic AI Moves Into Autonomous Workflows \u2014 AI Tech Journal",
    "articles/ai-code-assistants-future-of-software-engineering.html": "The Senior Engineer in the AI Codegen Era \u2014 AI Tech Journal",
    "articles/biometric-defenses-deepfake-identity-theft.html": "Defeating Real-Time Voice Cloning Fraud \u2014 AI Tech Journal",
    "articles/clean-energy-fusion-ai-data-center-power.html": "The Race to Power Gigawatt AI Data Centers \u2014 AI Tech Journal",
    "articles/humanoid-robotics-manufacturing-automation.html": "Humanoid Robots Join Automotive Assembly \u2014 AI Tech Journal",
    "articles/multimodal-reasoning-vision-language-models.html": "VLMs Learn to Perceive 3D Physical Reality \u2014 AI Tech Journal",
    "articles/neural-interface-wearables-spatial-computing.html": "Neural Wristbands Replace Spatial Gestures \u2014 AI Tech Journal",
    "articles/neuromorphic-chips-brain-inspired-computing.html": "Neuromorphic Silicon Hits 100x Efficiency \u2014 AI Tech Journal",
    "articles/next-gen-local-llms-open-source-revolution.html": "Running 70B Reasoning Models at Home \u2014 AI Tech Journal",
    "articles/quantum-computing-breakthrough-error-correction.html": "Quantum Computing Crosses a Key Threshold \u2014 AI Tech Journal",
    "articles/silicon-valley-ai-venture-funding-shifts.html": "Sand Hill Road Backs Vertical AI Foundries \u2014 AI Tech Journal",
    "articles/synthetic-data-breakthroughs-model-training.html": "Synthetic Data Overtakes Web Scraping \u2014 AI Tech Journal",
    "articles/webassembly-and-edge-ai-redefining-software.html": "Zero-Latency AI Inference in the Browser \u2014 AI Tech Journal",
    "articles/zero-trust-security-in-ai-driven-enterprises.html": "Zero Trust in the Age of Autonomous Agents \u2014 AI Tech Journal",
}

DESCRIPTIONS = {
    "index.html": "Independent technical reporting on artificial intelligence, quantum computing, software architecture, and cybersecurity.",
    "about.html": "AI Tech Journal is an independent technology publication covering artificial intelligence, computing, and deep tech.",
    "articles/agentic-ai-autonomous-workflows-2025.html": "Autonomous multi-agent systems are turning enterprise software from passive assistants into self-orchestrating task forces.",
    "articles/ai-code-assistants-future-of-software-engineering.html": "AI code generation has shifted engineering from syntax production to architecture validation and formal verification.",
    "articles/clean-energy-fusion-ai-data-center-power.html": "With AI data centers projected to consume over 8% of US electricity by 2028, cloud providers are signing direct nuclear power deals.",
    "articles/humanoid-robotics-manufacturing-automation.html": "Vision-action neural models let bipedal robots handle delicate wiring harnesses that previously baffled rigid robotic arms.",
    "articles/neural-interface-wearables-spatial-computing.html": "Sub-millimeter EMG wristbands detect neuromuscular intent before hands move, unlocking invisible control for smart glasses.",
    "articles/next-gen-local-llms-open-source-revolution.html": "New 2-bit quantization and unified memory let high-end reasoning models run privately on everyday workstations.",
    "articles/quantum-computing-breakthrough-error-correction.html": "A neutral-atom demonstration suppresses error rates by three orders of magnitude, bringing quantum machines closer.",
    "articles/synthetic-data-breakthroughs-model-training.html": "With public internet text largely exhausted, self-correcting synthetic data has become frontier AI's main training fuel.",
    "articles/zero-trust-security-in-ai-driven-enterprises.html": "When autonomous agents execute code and touch private data, identity perimeters collapse. How CISOs enforce machine boundaries.",
}

# image intrinsic dimensions (w, h); svg entries only used when an img lacks attrs
DIMS = {
    "agentic-ai.jpg": (1200, 1500),
    "ai-code-assistants.jpg": (1200, 800),
    "author-david.jpg": (400, 600),
    "author-elena.jpg": (400, 500),
    "author-marcus.jpg": (400, 600),
    "author-sophia.jpg": (400, 599),
    "biometric-defenses.jpg": (1200, 800),
    "category-ai.jpg": (1200, 675),
    "category-business.jpg": (1200, 800),
    "category-cybersecurity.jpg": (1200, 801),
    "category-future.jpg": (1200, 800),
    "category-gadgets.jpg": (1200, 1200),
    "category-software.jpg": (1200, 800),
    "category-tech.jpg": (1200, 800),
    "category-tools.jpg": (1200, 800),
    "clean-fusion-datacenter.jpg": (1200, 798),
    "cybersecurity-zero-trust.jpg": (1200, 800),
    "hero-ai-frontier.jpg": (1200, 912),
    "humanoid-robotics.jpg": (1200, 800),
    "local-llms.jpg": (1200, 801),
    "logo.svg": (48, 48),
    "multimodal-vision.jpg": (1200, 800),
    "neural-wearables.jpg": (1200, 1206),
    "neuromorphic-chips.jpg": (1200, 800),
    "quantum-computing.jpg": (1200, 800),
    "synthetic-data.jpg": (1200, 800),
    "venture-funding.jpg": (1200, 800),
    "webassembly-edge.jpg": (1200, 800),
}

EMAIL_CTA = (
    '<a class="newsletter-btn" href="mailto:{email}?subject=Subscribe%20to%20the%20AI%20Tech%20Journal%20briefing" '
    'style="display:inline-block;padding:12px 26px;border-radius:9999px;text-decoration:none;font-weight:700;">'
    'Subscribe by email</a>'
    '<p class="newsletter-disclaimer" style="margin-top:14px;">This opens your email app with a ready-to-send message. '
    'Nothing is stored on this site.</p>'
)

OG_FALLBACK = """  <meta property="og:type" content="website">
  <meta property="og:site_name" content="AI Tech Journal">
  <meta property="og:url" content="{url}">
  <meta property="og:title" content="{title}">
  <meta property="og:description" content="{desc}">
  <meta property="og:image" content="{img}">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="{title}">
  <meta name="twitter:description" content="{desc}">
  <meta name="twitter:image" content="{img}">
"""

AD_RE = re.compile(r'\n?[ \t]*<div class="ad-slot-wrapper">.*?<div class="ad-placeholder-text">.*?</div>\s*</div>\s*</div>\n?', re.S)
FORM_RE = re.compile(r'[ \t]*<form class="newsletter-form">.*?</form>\s*\n?[ \t]*<p class="newsletter-disclaimer">.*?</p>', re.S)
IMG_RE = re.compile(r'<img\b[^>]*>', re.I)
ONERROR_RE = re.compile(r'\s+onerror="this\.src=\'[^\']*\'"', re.I)


def rel_of(path):
    return os.path.relpath(path, ROOT).replace("\\", "/")


def page_url(rel):
    u = urljoin(SITE + "/", rel)
    if u.endswith("/index.html"):
        u = u[: -len("index.html")]
    return u


def to_absolute(rel, value):
    if not value or value.startswith(("http://", "https://", "mailto:", "tel:", "#", "data:", "//")):
        return value
    u = urljoin(SITE + "/" + rel, value)
    if u.endswith("/index.html"):
        u = u[: -len("index.html")]
    return u


def src_attr(tag):
    m = re.search(r'\bsrc="([^"]*)"', tag, re.I)
    return m.group(1) if m else ""


def fix_jsonld(rel, block):
    def repl(m):
        return '"' + to_absolute(rel, m.group(1)) + '"'

    return re.sub(r'"((?:\.\.?/)[^"]*)"', repl, block)


def fix_img(rel, m, first_img_seen):
    tag = m.group(0)
    if "width=" not in tag or "height=" not in tag:
        name = os.path.basename(urlparse(src_attr(tag)).path)
        d = DIMS.get(name)
        if d:
            tag = tag[:-1].rstrip() + f' width="{d[0]}" height="{d[1]}"' + ">"
            tag = tag.replace("/ >", ">")
    if "decoding=" not in tag:
        tag = tag[:-1].rstrip() + ' decoding="async">'
    upper = tag.lower()
    eager = any(k in upper for k in (
        "brand-logo", "author-avatar", "author-detail-avatar", "fetchpriority",
        "hero-img-box", "article-main-image", 'loading=',
    ))
    if not eager:
        tag = tag[:-1].rstrip() + ' loading="lazy">'
    return tag


def add_head_bits(rel, text):
    base = "./" if "/" not in rel else "../"
    bits = []
    if 'rel="icon"' not in text:
        bits.append(f'  <link rel="icon" href="{base}favicon.svg" type="image/svg+xml">')
        bits.append(f'  <link rel="apple-touch-icon" href="{base}apple-touch-icon.png">')
    if 'name="theme-color"' not in text:
        bits.append('  <meta name="theme-color" content="#07090e">')
    if bits:
        text = text.replace("  <link rel=\"stylesheet\"", "\n".join(bits) + '\n\n  <link rel="stylesheet"', 1)
    return text


def add_og(rel, text):
    if 'property="og:url"' in text:
        if 'property="og:site_name"' not in text:
            text = re.sub(r'(<meta property="og:type"[^>]*>)',
                          r'\1\n  <meta property="og:site_name" content="AI Tech Journal">', text, count=1)
        return text
    title = TITLES.get(rel, "AI Tech Journal")
    desc = DESCRIPTIONS.get(rel) or (re.search(r'<meta name="description" content="([^"]*)"', text).group(1)
                                    if re.search(r'<meta name="description" content="([^"]*)"', text) else "")
    img = SITE + "/assets/images/hero-ai-frontier.jpg"
    block = OG_FALLBACK.format(url=page_url(rel), title=title.replace("&", "&amp;"),
                               desc=desc.replace("&", "&amp;"), img=img)
    return text.replace('  <link rel="canonical"', block + '  <link rel="canonical"', 1)


def process(path):
    rel = rel_of(path)
    text = open(path, encoding="utf-8-sig", newline="").read()
    orig = text
    url = page_url(rel)

    # --- dead links / broken markup ---
    text = ONERROR_RE.sub("", text)
    text = re.sub(r"\s+onerror=\"this\.src=&quot;[^\"]*&quot;\"", "", text)
    text = AD_RE.sub("\n", text)
    text = text.replace("<h4", "<h3").replace("</h4>", "</h3>")

    # --- fake claims / stale chrome ---
    text = text.replace(">Live Intel<", ">Top Story<")
    text = text.replace("<span>Updated Hourly</span>", "<span>Independent AI Coverage</span>")
    text = text.replace("ISSN 2831-904X \u2022 Published Daily",
                        "Independent AI &amp; Frontier Technology Publication")
    text = text.replace("Join 85,000+ AI researchers, founders, and senior engineers receiving our weekly Sunday deep dive.",
                        "One long-form deep dive on frontier AI, delivered every Sunday.")
    text = text.replace("&copy; 2025 AI Tech Journal. All rights reserved. Content protected by international copyright conventions.",
                        "&copy; 2025\u20132026 AI Tech Journal. All rights reserved.")
    text = re.sub(r'<td>\.(\d+)</td>', r'<td>$\1</td>', text)

    # --- newsletter form -> real mailto action ---
    cta = EMAIL_CTA.format(email=EMAIL)
    text = FORM_RE.sub(lambda m: "        " + cta, text)
    text = text.replace('href="#newsletter-signup" class="subscribe-btn-sm"',
                        f'href="mailto:{EMAIL}?subject=Subscribe%20to%20the%20AI%20Tech%20Journal%20briefing" class="subscribe-btn-sm"')

    # --- share links get a real URL ---
    if rel.startswith("articles/"):
        twitter_url = url.replace("&", "%26")
        text = re.sub(r'(https://twitter\.com/intent/tweet\?text=[^"]*)(")',
                      lambda m: m.group(1) + "%20" + twitter_url.replace(":", "%3A").replace("/", "%2F") + m.group(2), text)
        text = text.replace('https://www.linkedin.com/sharing/share-offsite/?url="',
                            'https://www.linkedin.com/sharing/share-offsite/?url=' + url.replace(":", "%3A").replace("/", "%2F") + '"')

    # --- accessibility: menu button wiring ---
    text = text.replace('<div class="mobile-nav-drawer">', '<div class="mobile-nav-drawer" id="mobile-navigation">')
    text = re.sub(r'<button class="mobile-menu-toggle" type="button" aria-label="Toggle Navigation Menu">',
                  '<button class="mobile-menu-toggle" type="button" aria-label="Open navigation menu" aria-expanded="false" aria-controls="mobile-navigation">', text)

    # --- titles + descriptions ---
    if rel in TITLES:
        text = re.sub(r"<title>.*?</title>", "<title>" + TITLES[rel].replace("&", "&amp;") + "</title>",
                      text, count=1, flags=re.S)
    if rel in DESCRIPTIONS:
        text = re.sub(r'(<meta name="description" content=")[^"]*(")',
                      lambda m: m.group(1) + DESCRIPTIONS[rel].replace("&", "&amp;") + m.group(2), text, count=1)

    # --- absolute canonical + social URLs ---
    text = re.sub(r'(<link rel="canonical" href=")([^"]*)(")',
                  lambda m: m.group(1) + to_absolute(rel, m.group(2)) + m.group(3), text)
    text = re.sub(r'(<meta property="og:url" content=")([^"]*)(")',
                  lambda m: m.group(1) + to_absolute(rel, m.group(2)) + m.group(3), text)
    text = re.sub(r'(<meta property="og:image" content=")([^"]*)(")',
                  lambda m: m.group(1) + to_absolute(rel, m.group(2)) + m.group(3), text)
    text = re.sub(r'(<meta name="twitter:image" content=")([^"]*)(")',
                  lambda m: m.group(1) + to_absolute(rel, m.group(2)) + m.group(3), text)
    text = re.sub(r'<script type="application/ld\+json">(.*?)</script>',
                  lambda m: '<script type="application/ld+json">' + fix_jsonld(rel, m.group(1)) + "</script>",
                  text, flags=re.S)

    # --- duplicate category art -> reuse the on-topic article image ---
    if rel == "categories/cybersecurity.html":
        text = text.replace("../assets/images/category-cybersecurity.jpg", "../assets/images/cybersecurity-zero-trust.jpg")
    if rel == "categories/technology.html":
        text = text.replace("../assets/images/category-tech.jpg", "../assets/images/clean-fusion-datacenter.jpg")

    # --- image sizing + lazy loading ---
    text = IMG_RE.sub(lambda m: fix_img(rel, m, False), text)

    # --- head additions ---
    text = add_og(rel, text)
    text = add_head_bits(rel, text)

    if text != orig:
        open(path, "w", encoding="utf-8-sig", newline="").write(text)
        return True
    return False


changed = 0
for p in sorted(glob.glob(os.path.join(ROOT, "**", "*.html"), recursive=True)):
    if os.sep + "_dev" + os.sep in p:
        continue
    if process(p):
        changed += 1
print(f"rewrote {changed} pages")
