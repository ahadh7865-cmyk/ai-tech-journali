import os, re

for dirpath, dirnames, filenames in os.walk('.'):
    dirnames[:] = [d for d in dirnames if d not in {'.git', '_dev'}]
    for f in filenames:
        if not f.endswith('.html'):
            continue
        p = os.path.join(dirpath, f)
        t = open(p, encoding='utf-8-sig', newline='').read()
        o = t
        t = re.sub(r'<td>\$(\d{3})</td>', r'<td>$0.\1</td>', t)
        # currency fix: $004 -> $0.004
        t = t.replace('width="1200" height="675" decoding="async" loading="lazy"',
                      'width="1200" height="1500" decoding="async"')
        t = t.replace(' class="hero-sub-img" width="1200" height="800" decoding="async" loading="lazy"',
                      ' class="hero-sub-img" width="1200" height="800" decoding="async"')
        t = t.replace(' class="hero-sub-img" width="1200" height="801" decoding="async" loading="lazy"',
                      ' class="hero-sub-img" width="1200" height="801" decoding="async"')
        if t != o:
            open(p, 'w', encoding='utf-8-sig', newline='').write(t)
            print('fixed', p)
