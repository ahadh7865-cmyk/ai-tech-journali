import os, re, glob
from urllib.parse import urlparse

SITE = 'https://ahadh7865-cmyk.github.io/ai-tech-journali'
ROOT = 'deploy'
missing = set()
checked = 0

for p in sorted(glob.glob(os.path.join(ROOT, '**', '*.html'), recursive=True)):
    t = open(p, encoding='utf-8-sig').read()
    for u in re.findall(r'https://ahadh7865-cmyk\.github\.io/ai-tech-journali/[^"\s<>]*', t):
        path = urlparse(u).path
        rel = path[len('/ai-tech-journali/'):] if path.startswith('/ai-tech-journali/') else ''
        if rel in ('', '/'):
            rel = 'index.html'
        checked += 1
        target = os.path.join(ROOT, rel)
        candidates = [target, target.rstrip('/') + '/index.html', target + '.html']
        if not any(os.path.exists(c) for c in candidates):
            missing.add((os.path.relpath(p, ROOT), u))

print(f'absolute SITE urls checked: {checked}')
print(f'missing targets: {len(missing)}')
for page, u in sorted(missing):
    print(f'  {page} -> {u}')
